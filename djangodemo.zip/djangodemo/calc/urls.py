from django.urls import path
from . import views

urlpatterns=[
    path('',views.home,name='home'),
    path('add/', views.show_addition_form, name='show_addition_form'),
    path('check-progress/', views.check_progress, name='check_progress'),
]

 