def add_numbers(a, b):
    """
    A simple function to add two numbers.
    """
    return a + b
