from django.shortcuts import render
from django.http import HttpResponse
from .utils import add_numbers
from .forms import ConstructionProgressForm


def home(request):
    return render(request, 'base.html')

def show_addition_form(request):
    """
    Display a simple form with two input fields and a button to add numbers.
    """
    result = None  # Initialize result variable
    if request.method == 'POST':
        # Get the numbers from the form input
        number1 = int(request.POST.get('number1', 0))
        number2 = int(request.POST.get('number2', 0))
        # Call the addition function
        result = add_numbers(number1, number2)

    # Render the template and pass the result
    return render(request, 'addition.html', {'result': result})

def check_progress(request):
    if request.method == 'POST':
        form = ConstructionProgressForm(request.POST, request.FILES)
        if form.is_valid():
            # Process the form data and handle the image and activity selection
            image = form.cleaned_data['image']
            activity = form.cleaned_data['activity']
            
            # Example processing using add_numbers (assuming you need some result from this)
            # For this example, I'm going to call it with arbitrary numbers
            # You may need to adjust this based on actual use
            # e.g., numbers might come from some other form fields or calculations
            # result = add_numbers(1, 2)  # Example usage
            
            return render(request, 'result.html', {
                'activity': activity,
                'image': image
            })
    else:
        form = ConstructionProgressForm()
    
    return render(request, 'check_progress.html', {'form': form})
